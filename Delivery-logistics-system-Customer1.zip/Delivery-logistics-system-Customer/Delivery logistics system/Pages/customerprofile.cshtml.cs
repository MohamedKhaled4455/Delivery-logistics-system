using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Delivery_logistics_system.Pages
{
    public class ProfileModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

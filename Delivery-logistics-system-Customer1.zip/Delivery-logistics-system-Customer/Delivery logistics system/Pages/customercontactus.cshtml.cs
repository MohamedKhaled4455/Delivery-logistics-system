using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Delivery_logistics_system.Pages
{
    public class Contact_usModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

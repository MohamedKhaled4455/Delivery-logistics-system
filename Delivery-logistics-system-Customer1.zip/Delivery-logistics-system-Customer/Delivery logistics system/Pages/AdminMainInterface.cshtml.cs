using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Delivery_logistics_system.Pages
{
    public class AdminMainInterfaceModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Delivery_logistics_system.Pages.Visitor
{
    public class contactModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

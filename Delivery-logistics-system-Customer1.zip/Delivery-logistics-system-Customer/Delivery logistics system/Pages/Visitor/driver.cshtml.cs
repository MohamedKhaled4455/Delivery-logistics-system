using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Delivery_logistics_system.Pages.Visitor
{
    public class driverModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

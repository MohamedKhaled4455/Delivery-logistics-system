using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Delivery_logistics_system.Pages
{
    public class My_ordersModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

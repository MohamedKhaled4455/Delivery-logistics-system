using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Delivery_logistics_system.Pages
{
    public class Ship_TrackModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
